P2PoolExtendFrontEnd
====================

Extended front end web interface for p2pool

How install
====================
Put all these files on web-static folder of your p2pool node installation